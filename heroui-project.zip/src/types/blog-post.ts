import { z } from "zod";

export const blogPostSchema = z.object({
  // Basic Information
  title: z.string().min(5, "Title must be at least 5 characters").max(100, "Title must be less than 100 characters"),
  description: z.string().min(20, "Description must be at least 20 characters").max(500, "Description must be less than 500 characters"),
  
  // Content Details
  content: z.string().min(100, "Content must be at least 100 characters"),
  category: z.string().min(1, "Please select a category"),
  tags: z.array(z.string()).min(1, "Add at least one tag").max(5, "Maximum 5 tags allowed"),
  
  // Media
  coverImage: z.array(z.object({
    file: z.instanceof(File),
    preview: z.string(),
    name: z.string(),
    size: z.number(),
  })).min(1, "Cover image is required").max(10, "Maximum 10 images allowed"),
  
  // Publishing Options
  publishDate: z.date().optional(),
  isDraft: z.boolean().default(false),
  isPublic: z.boolean().default(true),
});

export type BlogPostFormData = z.infer<typeof blogPostSchema>;

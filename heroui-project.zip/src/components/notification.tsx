import React from "react";
import { motion, AnimatePresence } from "framer-motion";

interface NotificationProps {
  message: string;
  isVisible: boolean;
  type?: "success" | "error" | "info";
}

export const Notification: React.FC<NotificationProps> = ({ 
  message, 
  isVisible,
  type = "success" 
}) => {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-lg shadow-md
            ${type === "success" ? "bg-success-100 text-success-600" : 
              type === "error" ? "bg-danger-100 text-danger-600" : 
              "bg-primary-100 text-primary-600"}`}
          role="alert"
          aria-live="assertive"
        >
          <p className="text-sm font-medium">{message}</p>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
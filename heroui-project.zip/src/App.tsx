import React from "react";
import { BlogPostForm } from "./components/blog-post-form";

export default function App() {
  return (
    <main className="min-h-screen bg-background">
      <BlogPostForm />
    </main>
  );
}
